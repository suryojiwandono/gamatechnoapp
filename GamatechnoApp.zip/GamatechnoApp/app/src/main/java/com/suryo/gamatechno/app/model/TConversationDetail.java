package com.suryo.gamatechno.app.model;

public class TConversationDetail {
    public String messageId;
    public String fromUserId;
    public String toUserId;
    public String fromUsername;
    public String toUsername;
    public String messageContent;
    public String status;
    public String messageStatus;
    public String timestamp;
}
