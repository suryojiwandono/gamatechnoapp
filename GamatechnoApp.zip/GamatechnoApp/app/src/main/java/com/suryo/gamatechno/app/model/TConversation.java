package com.suryo.gamatechno.app.model;

public class TConversation {
    public String userId;
    public String key;
    public String fullname;
    public String username;
    public String email;
    public String photo;
    public String location;
    public String flag;
    public String distance;
    public String timestamp;
    public int isOnline;
}
