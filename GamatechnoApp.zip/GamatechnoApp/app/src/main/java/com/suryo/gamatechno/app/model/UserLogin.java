package com.suryo.gamatechno.app.model;

public class UserLogin {
    public String userId;
    public String fullname;
    public String username;
    public String phone;
    public String email;
    public String role;
    public String token;
    public int status;
}
