package com.suryo.gamatechno.app.model;

public class MUser {
    public String userId;
    public String key;
    public String fullname;
    public String username;
    public String email;
    public String photo;
    public String location;
    public String flag;
    public String distance;
    public int isOnline;
}
